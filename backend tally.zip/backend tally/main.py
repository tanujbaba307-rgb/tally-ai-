from flask import Flask, request, jsonify
from flask_cors import CORS
import google.generativeai as genai
import os
import xml.etree.ElementTree as ET
from xml.dom import minidom
from datetime import datetime

app = Flask(__name__)
CORS(app)  # Netlify se connect hone ke liye

# Gemini AI setup - API key environment variable se lega
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)
    model = genai.GenerativeModel('gemini-pro')
else:
    print("WARNING: GEMINI_API_KEY not set!")

@app.route('/', methods=['GET'])
def home():
    return jsonify({
        "message": "Tally AI Agent Backend is running!",
        "status": "active",
        "endpoints": {
            "generate": "POST /generate - Send prompt to get XML"
        }
    })

@app.route('/generate', methods=['POST'])
def generate():
    try:
        data = request.json
        prompt = data.get('prompt', '')
        
        if not prompt:
            return jsonify({"error": "Prompt is required"}), 400
        
        # Agar API key nahi hai to sample XML return karo
        if not GEMINI_API_KEY:
            return jsonify({"xml": generate_sample_xml(prompt)})
        
        # AI se data extract karo
        try:
            ai_response = model.generate_content(f"""
            Convert this accounting entry to JSON format. Extract party name, amount, GST rate if mentioned.
            Input: {prompt}
            
            Return ONLY valid JSON like:
            {{"type": "purchase", "party": "abc trade", "amount": 50000, "gst": 18}}
            """)
            
            # Try to parse AI response
            import json as json_lib
            import re
            
            # Extract JSON from response
            text = ai_response.text
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                data = json_lib.loads(json_match.group())
            else:
                data = {"type": "purchase", "party": "customer", "amount": 50000, "gst": 18}
                
        except Exception as ai_error:
            print(f"AI Error: {ai_error}")
            data = {"type": "purchase", "party": "customer", "amount": 50000, "gst": 18}
        
        # XML generate karo
        xml_output = generate_tally_xml(data, prompt)
        
        return jsonify({"xml": xml_output})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def generate_tally_xml(data, original_prompt):
    """Simple XML generator"""
    
    # Default values
    voucher_type = data.get('type', 'purchase').lower()
    party = data.get('party', 'Party Name')
    amount = float(data.get('amount', 50000))
    gst = float(data.get('gst', 0)) if data.get('gst') else 0
    
    today = datetime.now().strftime("%Y%m%d")
    
    if voucher_type == 'purchase' or 'purchase' in original_prompt.lower():
        return generate_purchase_xml(party, amount, gst, today)
    elif voucher_type == 'sales' or 'sale' in original_prompt.lower():
        return generate_sales_xml(party, amount, gst, today)
    elif voucher_type == 'payment' or 'payment' in original_prompt.lower():
        return generate_payment_xml(party, amount, today)
    else:
        return generate_purchase_xml(party, amount, gst, today)

def generate_purchase_xml(party, amount, gst, date):
    """Purchase entry XML"""
    
    if gst > 0:
        gst_amount = (amount * gst / 100) / 2
        xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME></REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE>
          <VOUCHER VCHTYPE="Purchase" ACTION="Create">
            <DATE>{date}</DATE>
            <PARTYLEDGERNAME>{party}</PARTYLEDGERNAME>
            <VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>Purchases</LEDGERNAME>
              <AMOUNT>-{amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>CGST@{gst/2}%</LEDGERNAME>
              <AMOUNT>-{gst_amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>SGST@{gst/2}%</LEDGERNAME>
              <AMOUNT>-{gst_amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
          </VOUCHER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>'''
    else:
        xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME></REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE>
          <VOUCHER VCHTYPE="Purchase" ACTION="Create">
            <DATE>{date}</DATE>
            <PARTYLEDGERNAME>{party}</PARTYLEDGERNAME>
            <VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>Purchases</LEDGERNAME>
              <AMOUNT>-{amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
          </VOUCHER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>'''
    return xml

def generate_sales_xml(party, amount, gst, date):
    """Sales entry XML"""
    
    if gst > 0:
        gst_amount = (amount * gst / 100) / 2
        xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME></REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE>
          <VOUCHER VCHTYPE="Sales" ACTION="Create">
            <DATE>{date}</DATE>
            <PARTYLEDGERNAME>{party}</PARTYLEDGERNAME>
            <VOUCHERTYPENAME>Sales</VOUCHERTYPENAME>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>Sales</LEDGERNAME>
              <AMOUNT>{amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>CGST@{gst/2}%</LEDGERNAME>
              <AMOUNT>{gst_amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>SGST@{gst/2}%</LEDGERNAME>
              <AMOUNT>{gst_amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
          </VOUCHER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>'''
    else:
        xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME></REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE>
          <VOUCHER VCHTYPE="Sales" ACTION="Create">
            <DATE>{date}</DATE>
            <PARTYLEDGERNAME>{party}</PARTYLEDGERNAME>
            <VOUCHERTYPENAME>Sales</VOUCHERTYPENAME>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>Sales</LEDGERNAME>
              <AMOUNT>{amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
          </VOUCHER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>'''
    return xml

def generate_payment_xml(party, amount, date):
    """Payment entry XML"""
    
    xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME></REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE>
          <VOUCHER VCHTYPE="Payment" ACTION="Create">
            <DATE>{date}</DATE>
            <PARTYLEDGERNAME>Cash</PARTYLEDGERNAME>
            <VOUCHERTYPENAME>Payment</VOUCHERTYPENAME>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>{party}</LEDGERNAME>
              <AMOUNT>{amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>Cash</LEDGERNAME>
              <AMOUNT>-{amount:.2f}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
          </VOUCHER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>'''
    return xml

def generate_sample_xml(prompt):
    """Sample XML when AI is not available"""
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME></REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE>
          <VOUCHER VCHTYPE="Purchase" ACTION="Create">
            <DATE>20260401</DATE>
            <PARTYLEDGERNAME>ABC Trade</PARTYLEDGERNAME>
            <VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>Purchases</LEDGERNAME>
              <AMOUNT>-50000.00</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>CGST@9%</LEDGERNAME>
              <AMOUNT>-4500.00</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>SGST@9%</LEDGERNAME>
              <AMOUNT>-4500.00</AMOUNT>
            </ALLLEDGERENTRIES.LIST>
          </VOUCHER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>'''

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 10000))
    app.run(host='0.0.0.0', port=port)