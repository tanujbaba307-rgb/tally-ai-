\# Tally AI Agent Backend



Tally ke liye AI-powered XML generator backend.



\## API Endpoints



\- `GET /` - Status check

\- `POST /generate` - XML generate karo



\## Environment Variables



\- `GEMINI\_API\_KEY` - Google Gemini API key

